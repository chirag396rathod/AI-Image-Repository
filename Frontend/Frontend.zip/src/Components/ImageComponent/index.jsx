import React, { useState } from "react";
import { Badge, Image, Button, Avatar } from "antd";
import { styled } from "styled-components";
import {
  CommentOutlined,
  ShareAltOutlined,
  HeartOutlined,
  EyeOutlined,
  HeartFilled,
} from "@ant-design/icons";
import { LoaderImageContainer } from "../Loader";
import { COLOR_LIST, USER_ID } from "../../Utils/constants";
import { Toast } from "../Toater";
import axios from "axios";
import { FlexBox } from "../../globle-stled";
import { apiInstance } from "../../Utils/axios";
import CommentModal from "../CommentModal";
import ShareOnChatModal from "../ShareOnChatModal";

const ImageComponentContainer = styled.div`
  &:hover {
    .header {
      visibility: visible !important;
    }
  }
  .ant-image-mask {
    border-radius: 6px;
  }
  .ant-image-img {
    transition: ease-in 0.1s;
    object-fit: cover;
    width: 100%;
    max-height: 100%;
    border-radius: 6px;
    box-shadow: 2px 3px 6px rgba(0, 0, 0, 0.1);
    /* filter: blur(1); */
    position: relative;
  }
  &.flow {
    position: relative;
  }
  &:hover {
    .label {
      bottom: 0px !important;
      display: inline !important ;
    }
  }
  .label {
    position: absolute;
    background: #1a1110;
    padding: 10px;
    bottom: -150px;
    display: none;
    left: 0px;
    margin: 10px;
    border-radius: 6px;
    border-radius: 6px;
    text-overflow: ellipsis;
    overflow: hidden;
    z-index: 1;
    white-space: wrap;
    width: 290px;
    .title {
      color: #fff;
      font: 400 14px Poppins;
    }
  }
`;

const HeaderButtons = styled.div`
  position: absolute;
  top: 15px;
  right: 15px;
  z-index: 2;
  visibility: hidden;
`;
const FooterList = styled.div`
  margin-top: 10px;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .left {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .user-data {
      font: 400 14px Poppins;
      color: #fff;
      margin-left: 10px;
    }
  }
  .icon-div {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-direction: column;

    .index {
      text-align: color;
      font: 400 12px Poppins;
      color: #fff;
    }
    .action-icon {
      font-size: 22px;
      color: #fff;
      cursor: pointer;
    }
  }
`;

const ImageComponent = ({ data, key, isFrom, type }) => {
  const rendomFourDigit = Math.trunc(Math.abs(Math.random() * 4));
  const [isLoading, setLoading] = useState(false);
  const [isOpenComment, setIsOpenComment] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [post, setPost] = useState(data);
  const [selectedId, setSelectedId] = useState(null);
  const [input, setInput] = useState("");
  const [isOpenShareModal, setIsOpenShareModal] = useState({
    id: null,
    isOpen: false,
  });

  const handlePreview = () => {
    setShowPreview(!showPreview);
  };

  const handleComment = (id) => {
    setIsOpenComment(!isOpenComment);
    setSelectedId(id || null);
  };

  const handleShare = async () => {
    try {
      setLoading(true);
      const response = await apiInstance({
        method: "post",
        url: `${import.meta.env.VITE_BASE_API_URL}/share-image`,
        data: {
          prompt: post?.prompt,
          src: post?.src,
          user_id: USER_ID,
          type: type || "All",
        },
      });
      if (response?.status === 200) {
        setLoading(false);
        Toast({
          type: "success",
          massage: "Image Shared Successfully with Community!",
        });
      }
    } catch (error) {
      if (error) {
        setLoading(false);
        Toast({
          type: "error",
          massage:
            error?.response?.data?.error?.message || "Somthing went wrong!",
        });
      }
    }
  };

  const handleLike = async (post_id, user_id, action_val) => {
    try {
      const response = await apiInstance({
        method: "post",
        url: `${import.meta.env.VITE_BASE_API_URL}/like-dislike`,
        data: {
          post_id,
          user_id,
          action_val: action_val ? 0 : 1,
        },
      });
      const { status } = response;
      if (status === 200) {
        const newArray = { ...data };
        newArray.isLiked = action_val ? false : true;
        newArray.total_likes = action_val
          ? parseInt(post.total_likes) - 1
          : parseInt(post.total_likes) + 1;
        setPost(newArray);
      }
    } catch (error) {
      if (error) {
        Toast({
          type: "error",
          massage:
            error?.response?.data?.error?.message || "Somthing went wrong!",
        });
      }
    }
  };

  const handleOnShare = (data = null) => {
    if (data) {
      setIsOpenShareModal({
        id: data,
        isOpen: !isOpenShareModal.isOpen,
      });
    } else {
      setIsOpenShareModal({
        ...isOpenShareModal,
        isOpen: !isOpenShareModal.isOpen,
      });
    }
  };

  return (
    <div key={key}>
      <Badge.Ribbon
        text="Selected"
        style={{
          display: "none",
        }}
        key={key}
      >
        <ImageComponentContainer className="content flow">
          <HeaderButtons className={"header"}>
            <Button
              type="dashed"
              icon={<EyeOutlined />}
              className={isFrom && isFrom === "generate-image" && "mx-2"}
              onClick={handlePreview}
            >
              Preview
            </Button>
            {isFrom && isFrom === "generate-image" && (
              <Button
                type="primary"
                onClick={() => handleShare(post)}
                loading={isLoading}
              >
                Share
              </Button>
            )}
          </HeaderButtons>
          <Image
            width={"100%"}
            className="content flow"
            src={post.src}
            placeholder={<LoaderImageContainer />}
            preview={{
              visible: showPreview,
              mask: false,
              onVisibleChange: () => {
                handlePreview();
              },
            }}
          />
          {isFrom === "dashboard" && (
            <div className="label">
              <span className="title">
                {post.prompt.substring(0, 50) + "..."}
              </span>
              <FooterList>
                <div className="left">
                  <Avatar
                    style={{
                      background: COLOR_LIST[rendomFourDigit],
                      verticalAlign: "middle",
                    }}
                    size="large"
                  >
                    {post?.createdBy[0]?.name?.split("")[0]}
                  </Avatar>
                  <div className="user-data">{post?.createdBy[0]?.name}</div>
                </div>
                <FlexBox>
                  <div className="icon-div dual-icon-cover">
                    {post?.isLiked ? (
                      <HeartFilled
                        className="action-icon "
                        onClick={() =>
                          handleLike(post?._id, post?.user_id, post?.isLiked)
                        }
                      />
                    ) : (
                      <>
                        <HeartOutlined className="action-icon show-icon" />
                        <HeartFilled
                          className="action-icon show-hover-icon"
                          onClick={() =>
                            handleLike(post?._id, post?.user_id, post?.isLiked)
                          }
                        />
                      </>
                    )}

                    <div className="index mt-2">{post?.total_likes}</div>
                  </div>
                  <div className="icon-div">
                    <CommentOutlined
                      className="action-icon mx-3"
                      onClick={() => handleComment(post)}
                    />
                    <div className="index mt-2">{post?.total_comment}</div>
                  </div>
                  <div className="icon-div">
                    <ShareAltOutlined
                      className="action-icon"
                      onClick={() => handleOnShare(data)}
                    />
                    <div className="index  mt-2">2K</div>
                  </div>
                </FlexBox>
              </FooterList>
            </div>
          )}
        </ImageComponentContainer>
      </Badge.Ribbon>
      {isOpenComment && (
        <CommentModal
          isOpen={isOpenComment}
          toggle={handleComment}
          footer={null}
          data={selectedId}
          setInput={setInput}
          input={input}
          setPost={setPost}
          post={post}
        />
      )}
      {isOpenShareModal.isOpen && (
        <ShareOnChatModal
          isOpen={isOpenShareModal}
          toggle={handleOnShare}
          footer={null}
          data={isOpenComment}
        />
      )}
    </div>
  );
};

export default ImageComponent;
