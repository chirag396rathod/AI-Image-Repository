import React from "react";
import { Pagination } from "antd";
import { styled } from "styled-components";

const PaginationComponentContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 30px 0;
`;

const PaginationComponent = ({ curruntIndex, total, handlePageChange }) => {
  return (
    <PaginationComponentContainer>
      <Pagination
        defaultCurrent={curruntIndex || 1}
        total={total || 50}
        onChange={(e) => handlePageChange(e)}
        showSizeChanger={false}
      />
    </PaginationComponentContainer>
  );
};

export default PaginationComponent;
